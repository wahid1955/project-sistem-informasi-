<!DOCTYPE html>

<html lang="en">
  <head>
    <title>Signup</title>
    <link rel="stylesheet" href="styleLogin.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css">
  </head>
  <body>
    <div class="signup">
      <form action="formhandler.inc.php" method="post">
        <h1>Sign Up</h1>
        <label>Username</label>
        <input type="text" name="username" placeholder="Username">
        <label>E-mail</label>
        <input type="text" name="email" placeholder="E-mail">
        <label>Password</label>
        <input type="password"  name="pw" placeholder="Password">
        <button>Signup</button>
      </form>
    </div>
</body>
</html>
