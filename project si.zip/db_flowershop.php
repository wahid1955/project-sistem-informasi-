<?php
$dsn = "mysql:host=localhost;dbname=flowershop";
$dbusername ="admin";
$dbpassword ="kanggacha";



try{
    $pdo = new PDO($dsn, $dbusername, $dbpassword);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $err){
    echo"Connection failed: " . $e->getMessage();
}
?>